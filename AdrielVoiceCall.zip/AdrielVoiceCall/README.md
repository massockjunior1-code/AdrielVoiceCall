# Adrièl Voice Call

App Android native pour passer des appels et envoyer des SMS par commande vocale, liée à tes contacts.

## Commandes vocales reconnues

- **"Appelle [nom]"** ou **"Appel [nom]"** → lance l'appel direct vers ce contact
- **"Envoie un message à [nom] disant [texte]"** → envoie un SMS automatique

Exemples :
- "Appelle Maman"
- "Envoie un message à Junior disant je serai en retard"

## Comment obtenir le fichier APK (sans PC, via GitHub Actions)

1. **Crée un compte GitHub** (gratuit) si tu n'en as pas : https://github.com/signup

2. **Crée un nouveau repository** :
   - Nom : `AdrielVoiceCall`
   - Visibilité : Public ou Privé (les deux fonctionnent)
   - Ne coche aucune case (pas de README, pas de .gitignore)

3. **Upload tous les fichiers de ce projet** dans le repository :
   - Sur la page du repo vide, clique sur "uploading an existing file"
   - Glisse-dépose TOUS les fichiers et dossiers de ce projet (en gardant la même structure de dossiers)
   - Valide le commit ("Commit changes")

4. **Lance la compilation** :
   - Va dans l'onglet **"Actions"** du repository
   - Tu devrais voir le workflow "Build APK" se lancer automatiquement après l'upload
   - Si non, clique sur "Build APK" → "Run workflow" → "Run workflow" (bouton vert)

5. **Récupère ton APK** :
   - Attends 3-5 minutes que le workflow se termine (coche verte ✅)
   - Clique sur le workflow terminé
   - En bas de la page, dans "Artifacts", télécharge **"AdrielVoiceCall-debug-apk"**
   - Dézippe le fichier téléchargé → tu obtiens `app-debug.apk`

6. **Installe l'APK sur ton téléphone** :
   - Transfère le fichier `app-debug.apk` sur ton téléphone (via WhatsApp à toi-même, USB, ou Google Drive)
   - Ouvre le fichier → Android te demandera d'autoriser "Sources inconnues" → Autorise
   - Installe l'app normalement

7. **Première ouverture** :
   - L'app va demander 4 permissions : Micro, Appels, SMS, Contacts → **accepte tout**
   - Appuie sur le gros bouton micro et dis ta commande

## Limitations connues

- Le téléphone doit être **allumé** (aucune app ne fonctionne sur téléphone éteint)
- La recherche de contact est approximative (recherche le nom dans tous les contacts) — si plusieurs contacts contiennent "Marie" par exemple, ça prendra le premier trouvé
- Pas de mode mains-libres en arrière-plan dans cette version (il faut ouvrir l'app et appuyer sur le bouton) — une version améliorée avec mot-clé d'activation type "Ok Adrièl" peut être ajoutée ensuite

## Prochaines améliorations possibles

- Activation par mot-clé sans ouvrir l'app (service en arrière-plan)
- Confirmation vocale avant l'appel ("Tu veux appeler Maman, confirme ?")
- Gestion des contacts ambigus (proposer une liste si plusieurs correspondances)
