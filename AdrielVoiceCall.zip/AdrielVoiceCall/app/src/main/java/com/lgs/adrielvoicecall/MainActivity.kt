package com.lgs.adrielvoicecall

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.telephony.SmsManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var statusText: TextView
    private lateinit var btnEcouter: Button

    private val REQUEST_CODE_PERMISSIONS = 100

    private val permissionsNecessaires = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        btnEcouter = findViewById(R.id.btnEcouter)

        demanderPermissions()

        btnEcouter.setOnClickListener {
            demarrerEcoute()
        }
    }

    private fun demanderPermissions() {
        val permissionsManquantes = permissionsNecessaires.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (permissionsManquantes.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissionsManquantes.toTypedArray(),
                REQUEST_CODE_PERMISSIONS
            )
        }
    }

    private fun demarrerEcoute() {
        statusText.text = "🎙️ Écoute en cours... Parlez maintenant"

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Dites une commande, ex: Appelle Maman")
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val texteCommande = matches?.get(0) ?: ""
                statusText.text = "Commande reçue : \"$texteCommande\""
                traiterCommande(texteCommande)
            }

            override fun onError(error: Int) {
                statusText.text = "❌ Erreur de reconnaissance, réessayez"
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer.startListening(intent)
    }

    /**
     * Analyse la commande vocale et déclenche l'action correspondante.
     * Formats reconnus :
     *  - "appelle X" / "appel X"
     *  - "envoie un message à X disant ..." / "envoie un sms à X ..."
     */
    private fun traiterCommande(texte: String) {
        val commande = texte.lowercase().trim()

        when {
            commande.startsWith("appelle") || commande.startsWith("appel") -> {
                val nomContact = commande
                    .replace("appelle", "")
                    .replace("appel", "")
                    .trim()
                appelerContact(nomContact)
            }

            commande.startsWith("envoie un message à") || commande.startsWith("envoie un sms à") -> {
                // Exemple : "envoie un message à maman disant je suis en route"
                val reste = commande
                    .replace("envoie un message à", "")
                    .replace("envoie un sms à", "")
                    .trim()

                val partieDisant = reste.split(" disant ")
                val nomContact = partieDisant[0].trim()
                val message = if (partieDisant.size > 1) partieDisant[1].trim() else "Bonjour"

                envoyerSmsContact(nomContact, message)
            }

            else -> {
                statusText.text = "⚠️ Commande non reconnue. Essayez \"Appelle Maman\""
            }
        }
    }

    /**
     * Recherche un contact par nom (recherche partielle/insensible à la casse)
     * et retourne son numéro de téléphone, ou null si non trouvé.
     */
    private fun rechercherNumeroContact(nomRecherche: String): String? {
        val cursor: Cursor? = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )

        var numeroTrouve: String? = null

        cursor?.use {
            val nomIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numeroIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

            while (it.moveToNext()) {
                val nomContact = it.getString(nomIndex) ?: continue
                if (nomContact.lowercase().contains(nomRecherche.lowercase())) {
                    numeroTrouve = it.getString(numeroIndex)
                    return@use
                }
            }
        }

        return numeroTrouve
    }

    private fun appelerContact(nomContact: String) {
        val numero = rechercherNumeroContact(nomContact)

        if (numero == null) {
            statusText.text = "❌ Contact \"$nomContact\" introuvable"
            Toast.makeText(this, "Contact introuvable", Toast.LENGTH_SHORT).show()
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            statusText.text = "⚠️ Permission d'appel manquante"
            demanderPermissions()
            return
        }

        statusText.text = "📞 Appel de $nomContact en cours..."
        val intentAppel = Intent(Intent.ACTION_CALL).apply {
            data = Uri.parse("tel:$numero")
        }
        startActivity(intentAppel)
    }

    private fun envoyerSmsContact(nomContact: String, message: String) {
        val numero = rechercherNumeroContact(nomContact)

        if (numero == null) {
            statusText.text = "❌ Contact \"$nomContact\" introuvable"
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            statusText.text = "⚠️ Permission SMS manquante"
            demanderPermissions()
            return
        }

        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(numero, null, message, null, null)
            statusText.text = "✅ Message envoyé à $nomContact"
        } catch (e: Exception) {
            statusText.text = "❌ Échec de l'envoi du SMS"
        }
    }
}
